<?php
    echo "session expired...";
header("Refresh:2; URL=login.php");
?>
